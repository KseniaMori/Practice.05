﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Dishes
{
    public partial class Form1 : Form
    {
        // Словари для хранения учетных записей для разных форм
        private Dictionary<string, string> form2Accounts; // Для перехода на Form2
        private Dictionary<string, string> form3Accounts; // Для перехода на Form3
        private Dictionary<string, string> form4Accounts; // Для перехода на Form4

        public Form1()
        {
            InitializeComponent();
            InitializeAccounts();
        }

        private void InitializeAccounts()
        {
            // Учетные записи для перехода на Form2              Form2 f2 = new Form2(); f2.ShowDialog();
            form2Accounts = new Dictionary<string, string>
            {
                { "kaft93x@outlook.com", "8ntwUp" },
                { "hr6zdl@yandex.ru", "uzWC67" },
                { "o@outlook.com", "2L6KZG" }
            };

            // Учетные записи для перехода на Form3
            form3Accounts = new Dictionary<string, string>
            {
                { "dcu@yandex.ru", "YOyhfR" },
                { "19dn@outlook.com", "RSbvHv" },
                { "pa5h@mail.ru", "rwVDh9" }
            };

            // Учетные записи для перехода на Form4
            form4Accounts = new Dictionary<string, string>
            {
                { "281av0@gmail.com", "LdNyos" },
                { "8edmfh@outlook.com", "gynQMT" },
                { "sfn13i@mail.ru", "AtnDjr" },
                { "g0orc3x1@outlook.com", "JlFRCZ" }
            };
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {
            if (txtPassword.Text.Length < 4)
            {
                txtPassword.BackColor = Color.LightPink;
                button1.Enabled = false;
            }
            else
            {
                txtPassword.BackColor = Color.White;
                button1.Enabled = true;
            }
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            string login = txtLogin.Text.Trim();
            string password = txtPassword.Text;

            // Проверяем, заполнены ли поля
            if (string.IsNullOrEmpty(login) || string.IsNullOrEmpty(password))
            {
                MessageBox.Show("Пожалуйста, заполните все поля!", "Внимание",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            // Проверяем учетные данные для Form2
            if (form2Accounts.ContainsKey(login) && form2Accounts[login] == password)
            {
                // Создаем и показываем Form2            Form2 f2 = new Form2(); f2.ShowDialog();
                Form2 f2 = new Form2(); f2.ShowDialog();
                f2.Show();
                this.Hide();
                return;
            }

            // Проверяем учетные данные для Form3
            if (form3Accounts.ContainsKey(login) && form3Accounts[login] == password)
            {
                // Создаем и показываем Form3
                Form3 f3 = new Form3(); f3.ShowDialog();
                f3.Show();
                this.Hide();
                return;
            }

            // Проверяем учетные данные для Form4
            if (form4Accounts.ContainsKey(login) && form4Accounts[login] == password)
            {
                // Создаем и показываем Form4
                Form4 f4 = new Form4(); f4.ShowDialog();
                f4.Show();
                this.Hide();
                return;
            }

            // Если не подошли ни одни учетные данные
            MessageBox.Show("Неверный логин или пароль!", "Ошибка",
                MessageBoxButtons.OK, MessageBoxIcon.Error);

            // Очищаем поле пароля
            txtPassword.Clear();
            txtPassword.Focus();
        }

        // Дополнительные методы для улучшения функциональности:

        private void txtPassword_KeyPress(object sender, KeyPressEventArgs e)
        {
            // Авторизация по нажатию Enter в поле пароля
            if (e.KeyChar == (char)Keys.Enter)
            {
                button1_Click(sender, e);
            }
        }

        private void txtLogin_KeyPress(object sender, KeyPressEventArgs e)
        {
            // Переход к полю пароля по нажатию Enter в поле логина
            if (e.KeyChar == (char)Keys.Enter)
            {
                txtPassword.Focus();
            }
        }

        // Для выхода из приложения при закрытии формы
        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            Application.Exit();
        }

        // Добавьте эту кнопку в дизайнере формы
        private void btnClear_Click(object sender, EventArgs e)
        {
            txtLogin.Clear();
            txtPassword.Clear();
            txtLogin.Focus();
            button1.Enabled = false;
            txtPassword.BackColor = Color.White;
        }

        // Добавьте этот метод для информации о доступных аккаунтах
        private void btnInfo_Click(object sender, EventArgs e)
        {
            string info = "Доступные учетные записи:\n\n";

            info += "Для Form2:\n";
            foreach (var account in form2Accounts)
            {
                info += $"- {account.Key}\n";
            }

            info += "\nДля Form3:\n";
            foreach (var account in form3Accounts)
            {
                info += $"- {account.Key}\n";
            }

            info += "\nДля Form4:\n";
            foreach (var account in form4Accounts)
            {
                info += $"- {account.Key}\n";
            }

            info += $"\nВсего: {form2Accounts.Count + form3Accounts.Count + form4Accounts.Count} учетных записей";

            MessageBox.Show(info, "Информация об учетных записях",
                MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        // Добавьте метод для показа/скрытия пароля
        private bool isPasswordVisible = false;

        private void btnShowPassword_Click(object sender, EventArgs e)
        {
            isPasswordVisible = !isPasswordVisible;
            txtPassword.UseSystemPasswordChar = !isPasswordVisible;

            if (sender is Button btn)
            {
                btn.Text = isPasswordVisible ? "Скрыть пароль" : "Показать пароль";
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Form5 f5 = new Form5(); f5.ShowDialog();
            this.Hide();
            return;
        }
    }
}