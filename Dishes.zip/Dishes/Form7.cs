﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Dishes
{
 
    public partial class Form7 : Form
    {
        // Здесь будем хранить список товаров
        private Product currentProduct = null;

        public Form7()
        {
            InitializeComponent();
        }

        private void InitializeComponent()
        {
            throw new NotImplementedException();
        }

        private void Form7_Load(object sender, EventArgs e)
        {
            this.Text = "Управление товарами";
            this.Size = new System.Drawing.Size(500, 300);

            Button btnAddProduct = new Button
            {
                Text = "Добавить товар",
                Location = new Point(20, 20),
                Size = new Size(150, 30)
            };
            btnAddProduct.Click += BtnAddProduct_Click;

            Button btnEditProduct = new Button
            {
                Text = "Редактировать товар",
                Location = new Point(180, 20),
                Size = new Size(150, 30)
            };
            btnEditProduct.Click += BtnEditProduct_Click;

            this.Controls.Add(btnAddProduct);
            this.Controls.Add(btnEditProduct);
        }

        // Пример класса товара
        public class Product
        {
            public string Name { get; set; }
            public decimal Price { get; set; }
            public string ImageFileName { get; set; }
        }

        private void BtnAddProduct_Click(object sender, EventArgs e)
        {
            using (FormProduct form = new FormProduct())
            {
                if (form.ShowDialog() == DialogResult.OK)
                {
                    // Создаем новый товар
                    currentProduct = new Product
                    {
                        Name = form.ProductName,
                        Price = form.Price,
                        ImageFileName = form.ImageFileName
                    };

                    MessageBox.Show($"Товар '{form.ProductName}' добавлен!\n" +
                        $"Изображение: {form.ImageFileName ?? "нет"}");
                }
            }
        }

        private void BtnEditProduct_Click(object sender, EventArgs e)
        {
            if (currentProduct == null)
            {
                MessageBox.Show("Сначала создайте товар");
                return;
            }

            using (FormProduct form = new FormProduct(
                currentProduct.Name,
                currentProduct.Price,
                currentProduct.ImageFileName))
            {
                if (form.ShowDialog() == DialogResult.OK)
                {
                    // Обновляем товар
                    currentProduct.Name = form.ProductName;
                    currentProduct.Price = form.Price;
                    currentProduct.ImageFileName = form.ImageFileName;

                    MessageBox.Show($"Товар обновлен!");
                }
            }
        }
    }
   
}
