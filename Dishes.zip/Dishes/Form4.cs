﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Dishes
{
    public partial class Form4 : Form
    {
        public Form4()
        {
            InitializeComponent();
        }

        public Form4(string login)
        {
            Login = login;
        }

        public string Login { get; }

        private void button2_Click(object sender, EventArgs e)
        {
            Form5 f5 = new Form5(); f5.ShowDialog();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form1 f1 = new Form1(); f1.ShowDialog();
        }
    }
}
