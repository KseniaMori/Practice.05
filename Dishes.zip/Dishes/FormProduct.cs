﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Dishes
{
    public partial class FormProduct : Form
    {
        public FormProduct()
        {
        }

        public FormProduct(string name)
        {
            InitializeComponent();
        }

        public FormProduct(string name, decimal price, string imageFileName) : this(name)
        {
        }

        public string ImageFileName { get; internal set; }
        public decimal Price { get; internal set; }
    }
}
